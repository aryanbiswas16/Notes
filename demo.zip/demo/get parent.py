import json

class InteractionNode:
    def __init__(self, id, name, type, interactions, parent_id=None, parent_name=None, parent_type=None):
        self.id = id
        self.name = name
        self.type = type
        self.interactions = interactions
        self.parent_id = parent_id
        self.parent_name = parent_name
        self.parent_type = parent_type
    
    def get_parent(self):
        if self.parent_id:
            return {
                'id': self.parent_id,
                'name': self.parent_name,
                'type': self.parent_type
            }
        return None

def create_interaction_nodes(json_path):
    with open(json_path, 'r', encoding='utf-8') as file:
        data = json.loads(file.read())
    
    nodes = []
    
    def process_component(component, parent=None):
        if 'interactions' in component:
            nodes.append(InteractionNode(
                component['id'],
                component['name'],
                component['type'],
                component['interactions'],
                parent['id'] if parent else None,
                parent['name'] if parent else None,
                parent['type'] if parent else None
            ))
        
        if 'children' in component:
            for child in component['children']:
                process_component(child, component)
    
    for component in data['components']:
        if 'children' in component:
            for child in component['children']:
                process_component(child, component)
    
    return nodes

# Usage example
json_path = ".\\filtered_triggers.json"
interaction_nodes = create_interaction_nodes(json_path)

# Example of using the nodes
for node in interaction_nodes:
    print(f"\nInteraction Element: {node.name}")
    parent = node.get_parent()
    if parent:
        print(f"Parent: {parent['name']} (Type: {parent['type']})")
    print("Interactions:", json.dumps(node.interactions, indent=2))