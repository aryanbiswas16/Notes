import json
import os

json_path = "C:/Users/PC/OneDrive/Desktop/New folder/Desktop_wireframe.json"

def filter_trigger_events(children):
    filtered = []
    for child in children:
        filtered_item = None
        # Check if this item has trigger interactions
        has_trigger = False
        if 'interactions' in child:
            for interaction in child['interactions']:
                if 'trigger' in interaction:
                    has_trigger = True
                    break
        
        # Create filtered item if it has triggers or filtered children
        filtered_children = []
        if 'children' in child:
            filtered_children = filter_trigger_events(child['children'])
        
        if has_trigger or filtered_children:
            filtered_item = {
                'id': child.get('id'),
                'name': child.get('name'),
                'type': child.get('type')
            }
            if has_trigger:
                filtered_item['interactions'] = child['interactions']
            if filtered_children:
                filtered_item['children'] = filtered_children
            filtered.append(filtered_item)
            
    return filtered

# Read and parse JSON file
with open(json_path, 'r', encoding='utf-8') as file:
    file_content = file.read()
    
# Parse JSON
data = json.loads(file_content)
if not data or 'children' not in data:
    print("Error: Invalid JSON structure")
    exit()

# Get filtered components with hierarchy
filtered_components = filter_trigger_events(data['children'])

# Create output data
output_data = {
    'components': filtered_components,
    'count': sum(1 for _ in str(filtered_components).split('interactions') if _ != '') - 1
}

# Save filtered data to new JSON
output_path = os.path.join(os.path.dirname(json_path), 'filtered_triggers.json')
with open(output_path, 'w', encoding='utf-8') as outfile:
    json.dump(output_data, outfile, indent=2)